include("${CMAKE_CURRENT_LIST_DIR}/t_common_cTargets.cmake")
